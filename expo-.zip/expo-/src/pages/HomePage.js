import React from 'react';
import (View, Text) from 'react-native';

import HomePage from './src/pages/HomePage'

const HomePage = () => {

  return (

    <View>
    
      <Text> PUC Minas </Text>

    </View>
    
  );  

}

export default HomePage;